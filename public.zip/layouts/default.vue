<template>
  <div>
    <nuxt/>
  </div>
</template>

<script>
</script>
<style>
</style>
