export const state = () => ({
  adverts: {
    count: 10
  }
})

export const mutations = {}

export const actions = {}
