
# vamyar-nuxt 
Vamyar official front-end project 

# stack
NUXT (SSR) and Vuetify (UI kit)


#### by Ehsan Afshary (savvyversa--@--gmail.com) - IR tehran
