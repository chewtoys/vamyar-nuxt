import Vue from "vue"
import Siema from "vue2-siema"

Vue.use(Siema)
