<template>
  <nuxt/>
</template>
<script>
export default {
  layout: "site"
}
</script>
