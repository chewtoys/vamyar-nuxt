<template>
  <div/>
</template>

<script>
export default {
  components: {},
  layout: "admin"
}
</script>
