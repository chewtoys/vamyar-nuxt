<template>
  <nuxt-child/>
</template>
