<template>
  <div>
    <nuxt-child/>
  </div>
</template>
<script>
export default {}
</script>
