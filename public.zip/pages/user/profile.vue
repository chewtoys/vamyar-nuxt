<template>
  <nuxt/>
</template>
<script>
export default {
  meta: {
    title: "پروفایل من",
    breadcrumb: "پروفایل"
  },
  layout: "user"
}
</script>
