<template>
  <nuxt />
</template>
<script>
export default {
  layout: "user"
}
</script>
