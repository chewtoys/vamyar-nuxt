<template>
  <nuxt/>
</template>
<script>
export default {
  meta: {
    title: "آگهی های من",
    breadcrumb: "آگهی ها"
  },
  layout: "user"
}
</script>
