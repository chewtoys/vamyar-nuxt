<template>
  <div>
    <dashboard/>
  </div>
</template>
<script>
import Dashboard from "~/components/user/dashboard/dashboard.vue"

export default {
  components: { Dashboard },
  layout: "user"
}
</script>
