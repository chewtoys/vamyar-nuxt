<template>
  <div>
    <table><tr><th>C1</th></tr><tr><td>R1</td></tr></table>
  </div>
</template>
<script>
export default {}
</script>
