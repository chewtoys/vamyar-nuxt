<template>
  <nuxt/>
</template>
